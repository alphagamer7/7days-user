<div style="height:100%;width:100%;background-color:#ebebeb;margin:0;padding:0" bgcolor="#ebebeb">
    <center>
        <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%"
            id="m_6753640329829520613bodyTable"
            style="height:100%;border-collapse:collapse;width:100%;background-color:#ebebeb;margin:0;padding:0"
            bgcolor="#ebebeb">
            <tbody>
                <tr>
                    <td align="center" valign="top" id="m_6753640329829520613bodyCell"
                        style="height:100%;width:100%;border-top-width:0;margin:0;padding:10px">


                        <table border="0" cellpadding="0" cellspacing="0" width="100%"
                            style="border-collapse:collapse;max-width:600px!important;border:0">
                            <tbody>
                                <tr>
                                    <td style="line-height:32px">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td valign="top" id="m_6753640329829520613templatePreheader"
                                        style="border-top-color:#45C261;border-top-style:solid;border-top-width:6px;border-bottom-width:0;padding-top:9px;padding-bottom:9px;background:#ffffff none no-repeat center/cover"
                                        bgcolor="#ffffff">

                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" id="m_6753640329829520613templateBody"
                                        style="border-top-width:0;border-bottom-color:#eaeaea;border-bottom-width:2px;border-bottom-style:none;padding-top:0;padding-bottom:9px;background:#ffffff none no-repeat center/cover"
                                        bgcolor="#ffffff">
                                        <table border="0" cellpadding="0" cellspacing="0" width="100%"
                                            style="min-width:100%;border-collapse:collapse">
                                            <tbody>
                                                <tr>
                                                    <td valign="top" style="padding-top:9px">

                                                        <table align="left" border="0" cellpadding="0" cellspacing="0"
                                                            style="max-width:100%;min-width:100%;border-collapse:collapse"
                                                            width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td valign="top"
                                                                        style="font-family:'Open Sans',Helvetica,Arial,sans-serif;font-size:16px;padding:0 32px 9px">

                                                                        <p
                                                                            style="color:#333333;margin:10px 0;padding:0">
                                                                            Hi ,</p>
                                                                        <p
                                                                            style="color:#333333;margin:10px 0;padding:0">
                                                                            To complete your reset password process,
                                                                            please verify your
                                                                            email and otp: </p>

                                                                        <table border="0" cellpadding="0"
                                                                            cellspacing="0" width="100%"
                                                                            style="min-width:100%;border-collapse:collapse">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td style="padding:30px"
                                                                                        valign="top" align="center">
                                                                                        <table border="0"
                                                                                            cellpadding="0"
                                                                                            cellspacing="0"
                                                                                            style="border-collapse:separate!important;border-radius:5px;background-color:#45C261"
                                                                                            bgcolor="#45C261">
                                                                                            <tbody>
                                                                                                <tr>
                                                                                                    <p> <span
                                                                                                            style="font-weight: bold;">OTP
                                                                                                            : </span>
                                                                                                        <?php echo $code; ?>
                                                                                                    </p>
                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                        <p
                                                                            style="color:#333333;margin:10px 0;padding:0">
                                                                            Thank you,<br>
                                                                            <?php echo $name; ?> Team
                                                                        </p>

                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>


                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top" id="m_6753640329829520613templateFooter"
                                        style="border-top-width:0;border-bottom-width:0;padding-top:16px;padding-bottom:16px;background:#f7f7f7 none no-repeat center/cover"
                                        bgcolor="#f7f7f7">
                                        <table border="0" cellpadding="0" cellspacing="0" width="100%"
                                            style="min-width:100%;border-collapse:collapse">
                                            <tbody>
                                                <tr>
                                                    <td valign="top" style="padding-top:9px">



                                                        <table align="left" border="0" cellpadding="0" cellspacing="0"
                                                            style="max-width:100%;min-width:100%;border-collapse:collapse"
                                                            width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td valign="top"
                                                                        style="padding-top:0;padding-bottom:9px;font-size:12px;font-family:'Open Sans',Helvetica,Arial,sans-serif;word-break:break-word;color:#656565;line-height:150%;text-align:center"
                                                                        align="center">

                                                                        <em>Copyright © 2020 <?php echo $name; ?>, Inc.</em>
                                                                        <br> <?php echo $address; ?>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>


                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>


                    </td>
                </tr>
            </tbody>
        </table>
    </center>
    <div class="yj6qo"></div>
    <div class="adL">


    </div>
</div>
</div>