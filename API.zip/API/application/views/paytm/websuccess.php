<!DOCTYPE html>
<html>
    <head>
        <title>PayTM</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <script type="text/javascript">
        function codeAddress() {
            window.location.href ='<?php echo $callback; ?>';
        }
        window.onload = codeAddress;
        </script>
    </head>
    <body>
    
    </body>
</html>