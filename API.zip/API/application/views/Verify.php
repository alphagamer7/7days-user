<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Verifications</title>
    <style>
        body{
            background:#e9ecef;
            font-family: Arial, Helvetica, sans-serif;
        }
        .title{
            text-align:center;
        }
        .message{
            text-align:center;
        }
    </style>
</head>
<body>
  <div>
      <h1 class="title">Thank You!</h1>
      <p class="message">Your email is succssfully verified</p>
  </div>
</div>
</body>
</html>